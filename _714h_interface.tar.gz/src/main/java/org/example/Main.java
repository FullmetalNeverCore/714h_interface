package org.example;

import javafx.application.Application;

public class Main {
    public static void main(String[] args) {
        Application.launch(ExampleFX.class,args);
    }
}